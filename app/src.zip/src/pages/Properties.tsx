import { useState, useEffect } from "react";
import { PropertyCard } from "@/components/PropertyCard";
import { PropertyForm } from "@/components/PropertyForm";
import { OfferForm } from "@/components/OfferForm";
import { useWallet } from "@/hooks/useWallet";
import { usePropertyActions } from "@/hooks/usePropertyActions";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Property } from "@/lib/mockData";
import { PlusCircle, Search, SlidersHorizontal, RefreshCw, Home } from "lucide-react";

export default function Properties() {
  const { publicKey } = useWallet();
  const {
    properties,
    listProperty,
    updateProperty,
    makeOffer,
    executeSale,
    getPropertyOffers,
  } = usePropertyActions();

  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [showOfferDialog, setShowOfferDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  // Simulate loading state
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const handleAddProperty = (formData: Omit<Property, 'property_id' | 'owner' | 'is_active' | 'created_at' | 'updated_at' | 'nft_mint'>) => {
    listProperty(formData);
  };

  const handleMakeOffer = (property: Property) => {
    setSelectedProperty(property);
    setShowOfferDialog(true);
  };

  const handleOfferSubmit = (amount: number) => {
    if (selectedProperty) {
      makeOffer(selectedProperty, amount);
      setShowOfferDialog(false);
      setSelectedProperty(null);
    }
  };

  const handleUpdateProperty = (property: Property) => {
    // TODO: Implement property update dialog
    console.log('Update property:', property);
  };

  const handleExecuteSale = (property: Property) => {
    const offers = getPropertyOffers(property.property_id);
    const acceptedOffer = offers.find(offer => offer.status === 'Accepted');
    if (acceptedOffer) {
      executeSale(property, acceptedOffer);
    }
  };

  // Filter properties based on search query
  const filteredProperties = properties.filter(
    (property) =>
      property.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container mx-auto py-8 animate-fade-in">
      {/* Hero section with new color scheme */}
      <div className="relative mb-16 rounded-2xl overflow-hidden bg-[#BDDDE4]/90">
        <div className="absolute inset-0 bg-gradient-to-r from-[#BDDDE4] to-[#9CC8D3] opacity-90"></div>
        <div className="relative z-10 py-16 px-10 text-gray-800">
          <div className="max-w-2xl">
            <h1 className="text-4xl font-bold mb-6">Find Your Dream Property</h1>
            <p className="text-gray-700 text-lg leading-relaxed mb-8">
              Browse our exclusive collection of real estate properties available as NFTs on the blockchain.
            </p>
            <div className="flex">
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="bg-white text-[#4A7D8A] hover:bg-white/90 flex items-center gap-3 rounded-full shadow-lg px-6 py-2.5 text-sm font-medium border border-[#9CC8D3]">
                    <PlusCircle className="h-4 w-4" />
                    List Your Property
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>List New Property</DialogTitle>
                  </DialogHeader>
                  <PropertyForm onSubmit={handleAddProperty} />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 right-0 w-1/3 h-full opacity-20 pointer-events-none">
          <Home className="w-full h-full text-gray-800" />
        </div>
      </div>

      {/* Search and filters */}
      <div className="mb-12">
        <div className="flex flex-col md:flex-row gap-5">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search by location..."
              className="pl-12 pr-4 py-3 w-full rounded-lg border border-gray-300 dark:border-gray-700 focus:outline-none focus:ring-2 focus:ring-[#BDDDE4] dark:focus:ring-[#9CC8D3] focus:border-transparent bg-white dark:bg-gray-800"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button 
            variant="outline" 
            className="flex items-center gap-3 px-5 py-2.5 border-[#BDDDE4] text-gray-700 hover:bg-[#BDDDE4]/10"
            onClick={() => setShowFilters(!showFilters)}
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filters
          </Button>
          <Button
            variant="ghost"
            className="flex items-center gap-3 px-5 py-2.5 text-gray-700 hover:bg-[#BDDDE4]/10"
            onClick={() => {
              setIsLoading(true);
              setTimeout(() => setIsLoading(false), 1000);
            }}
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        {/* Filter panel (collapsed by default) */}
        {showFilters && (
          <div className="mt-6 p-6 bg-[#BDDDE4]/10 dark:bg-gray-800/50 rounded-lg animate-slide-up border border-[#BDDDE4]/30">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-gray-700">Price Range</label>
                <div className="flex items-center gap-3">
                  <input
                    type="number"
                    placeholder="Min"
                    className="w-full p-3 rounded border border-gray-300 focus:ring-2 focus:ring-[#BDDDE4] focus:border-transparent"
                  />
                  <span>-</span>
                  <input
                    type="number"
                    placeholder="Max"
                    className="w-full p-3 rounded border border-gray-300 focus:ring-2 focus:ring-[#BDDDE4] focus:border-transparent"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-gray-700">Bedrooms</label>
                <select className="w-full p-3 rounded border border-gray-300 focus:ring-2 focus:ring-[#BDDDE4] focus:border-transparent">
                  <option value="">Any</option>
                  <option value="1">1+</option>
                  <option value="2">2+</option>
                  <option value="3">3+</option>
                  <option value="4">4+</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-gray-700">Bathrooms</label>
                <select className="w-full p-3 rounded border border-gray-300 focus:ring-2 focus:ring-[#BDDDE4] focus:border-transparent">
                  <option value="">Any</option>
                  <option value="1">1+</option>
                  <option value="2">2+</option>
                  <option value="3">3+</option>
                </select>
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-sm font-medium text-gray-700">Property Type</label>
                <select className="w-full p-3 rounded border border-gray-300 focus:ring-2 focus:ring-[#BDDDE4] focus:border-transparent">
                  <option value="">All Types</option>
                  <option value="house">House</option>
                  <option value="apartment">Apartment</option>
                  <option value="condo">Condo</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end mt-6">
              <Button
                variant="outline"
                size="sm"
                className="mr-3 px-5 border-[#BDDDE4] text-gray-700 hover:bg-[#BDDDE4]/10"
                onClick={() => setShowFilters(false)}
              >
                Cancel
              </Button>
              <Button 
                size="sm"
                className="px-5 bg-[#BDDDE4] hover:bg-[#9CC8D3] text-gray-800"
                onClick={() => setShowFilters(false)}
              >
                Apply Filters
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Property listings */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold mb-8 text-gray-800">Available Properties</h2>
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
            {[...Array(6)].map((_, i) => (
              <div 
                key={i} 
                className="w-[360px] h-[420px] rounded-xl bg-[#BDDDE4]/10 dark:bg-gray-800/50 animate-pulse flex flex-col"
              >
                <div className="h-48 w-full bg-[#BDDDE4]/30 dark:bg-gray-700 rounded-t-xl"></div>
                <div className="p-5 flex-grow">
                  <div className="h-6 bg-[#BDDDE4]/30 dark:bg-gray-700 rounded w-3/4 mb-5"></div>
                  <div className="h-4 bg-[#BDDDE4]/30 dark:bg-gray-700 rounded w-1/2 mb-6"></div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="h-12 bg-[#BDDDE4]/30 dark:bg-gray-700 rounded"></div>
                    <div className="h-12 bg-[#BDDDE4]/30 dark:bg-gray-700 rounded"></div>
                    <div className="h-12 bg-[#BDDDE4]/30 dark:bg-gray-700 rounded"></div>
                  </div>
                </div>
                <div className="p-5">
                  <div className="h-10 bg-[#BDDDE4]/30 dark:bg-gray-700 rounded w-1/3 ml-auto"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center">
            {filteredProperties.map((property) => (
              <PropertyCard
                key={property.property_id}
                property={property}
                onUpdateProperty={handleUpdateProperty}
                onMakeOffer={handleMakeOffer}
                onExecuteSale={handleExecuteSale}
                offers={getPropertyOffers(property.property_id)}
              />
            ))}
          </div>
        )}

        {!isLoading && filteredProperties.length === 0 && (
          <div className="text-center py-16 bg-[#BDDDE4]/10 dark:bg-gray-800/30 rounded-xl border border-[#BDDDE4]/30">
            <div className="mx-auto w-20 h-20 flex items-center justify-center bg-[#BDDDE4]/20 dark:bg-indigo-900/30 rounded-full mb-6">
              <Home className="h-10 w-10 text-[#4A7D8A] dark:text-indigo-400" />
            </div>
            <h3 className="text-xl font-medium mb-3 text-gray-800">No properties found</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
              {searchQuery 
                ? `No properties matching "${searchQuery}". Try a different search.` 
                : "No properties listed yet. Add your first property!"}
            </p>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="px-6 py-2.5 bg-[#BDDDE4] hover:bg-[#9CC8D3] text-gray-800">List New Property</Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>List New Property</DialogTitle>
                </DialogHeader>
                <PropertyForm onSubmit={handleAddProperty} />
              </DialogContent>
            </Dialog>
          </div>
        )}
      </div>

      <Dialog open={showOfferDialog} onOpenChange={setShowOfferDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Make an Offer</DialogTitle>
          </DialogHeader>
          {selectedProperty && (
            <OfferForm
              property={selectedProperty}
              onSubmit={handleOfferSubmit}
              onCancel={() => setShowOfferDialog(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}