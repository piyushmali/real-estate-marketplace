import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/button";
import { Home, Bed, Bath, ArrowRight, MapPin, Edit, DollarSign, CheckCircle, Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { useWallet } from "@/hooks/useWallet";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

import { Property, Offer } from "@/lib/mockData";

interface PropertyCardProps {
  property: Property;
  onUpdateProperty?: (property: Property) => void;
  onMakeOffer?: (property: Property) => void;
  onExecuteSale?: (property: Property, offer: Offer) => void;
  offers?: Offer[];
}

export const PropertyCard = ({ property, onUpdateProperty, onMakeOffer, onExecuteSale, offers = [] }: PropertyCardProps) => {
  const { publicKey } = useWallet();
  const [showActions, setShowActions] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  
  const isOwner = publicKey?.toBase58() === property.owner.toBase58();
  const hasPendingOffers = offers.some(offer => offer.status === 'Pending');
  
  // Generate a random gradient for each property card based on the #BDDDE4 palette
  const gradientColors = [
    "from-[#BDDDE4] to-[#9CC8D3]",
    "from-[#9CC8D3] to-[#7AACBA]",
    "from-[#8BBCCD] to-[#68A0BC]",
    "from-[#ADC8CC] to-[#9CC8D3]",
    "from-[#9CC8D3] to-[#8BBCCD]"
  ];
  
  const randomGradient = gradientColors[Math.floor(Math.random() * gradientColors.length)];
  
  return (
    <Card 
      className="w-[360px] h-[420px] flex flex-col overflow-hidden transition-all duration-300 property-card-hover rounded-xl border border-[#BDDDE4]/50 dark:border-gray-800 m-2 relative animate-fade-in shadow-md"
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      {/* Favorite button */}
      <button 
        className="absolute left-4 top-4 z-10 p-2 bg-white/80 dark:bg-black/50 backdrop-blur-sm rounded-full shadow-md transition-all duration-200 hover:scale-110"
        onClick={(e) => {
          e.stopPropagation();
          setIsFavorite(!isFavorite);
        }}
      >
        <Heart 
          className={cn(
            "h-5 w-5 transition-colors duration-200", 
            isFavorite ? "fill-rose-500 text-rose-500" : "text-gray-500 dark:text-gray-400"
          )} 
        />
      </button>

      {/* Action buttons */}
      {showActions && (
        <div className="absolute right-4 top-4 z-10 flex flex-col gap-2 animate-slide-up">
          {isOwner ? (
            <>
              <Button
                size="sm"
                variant="secondary"
                className="flex items-center gap-2 bg-white/90 dark:bg-black/70 backdrop-blur-sm shadow-md text-[#4A7D8A]"
                onClick={() => onUpdateProperty?.(property)}
              >
                <Edit className="h-4 w-4" />
                Update
              </Button>
              {hasPendingOffers && (
                <Button
                  size="sm"
                  variant="secondary"
                  className="flex items-center gap-2 bg-white/90 dark:bg-black/70 backdrop-blur-sm shadow-md text-[#4A7D8A]"
                  onClick={() => onExecuteSale?.(property, offers[0])}
                >
                  <CheckCircle className="h-4 w-4" />
                  Execute Sale
                </Button>
              )}
            </>
          ) : (
            <Button
              size="sm"
              variant="secondary"
              className="flex items-center gap-2 bg-white/90 dark:bg-black/70 backdrop-blur-sm shadow-md hover:bg-white/100 dark:hover:bg-black/90 text-[#4A7D8A]"
              onClick={() => onMakeOffer?.(property)}
            >
              <DollarSign className="h-4 w-4" />
              Make Offer
            </Button>
          )}
        </div>
      )}

      {/* Property image with overlay */}
      <div className="relative w-full h-48 overflow-hidden group">
        <div className={cn("absolute inset-0 bg-gradient-to-r", randomGradient, "opacity-80")}></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 z-10"></div>
        <img
          src={property.metadata_uri}
          alt={`Property in ${property.location}`}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          onError={(e) => {
            e.currentTarget.src = "/api/placeholder/400/200";
          }}
        />
        <Badge className="absolute bottom-4 left-4 z-20 bg-white/90 dark:bg-black/80 text-[#4A7D8A] dark:text-white font-bold text-sm px-3 py-1 rounded-full shadow-md">
          ${property.price.toLocaleString()}
        </Badge>
        
        <div className="absolute top-4 right-4 z-20">
          <Badge className="bg-[#9CC8D3] text-gray-800 font-semibold text-xs px-3 py-1 rounded-full">
            {property.nft_status}
          </Badge>
        </div>
      </div>
      
      <CardHeader className="py-4 px-5 pb-0">
        <div className="flex items-start gap-2">
          <MapPin className="size-4 text-[#4A7D8A] mt-1 flex-shrink-0" />
          <div>
            <CardTitle className="text-base font-bold line-clamp-1 text-gray-800">{property.location}</CardTitle>
            <p className="text-xs text-gray-500 mt-1">{property.property_id}</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="py-4 px-5 flex-grow">
        <div className="grid grid-cols-3 gap-4 text-sm">
          <div className="flex flex-col items-center p-3 bg-[#BDDDE4]/10 dark:bg-gray-900 rounded-lg">
            <Home className="size-5 text-[#4A7D8A] dark:text-blue-400 mb-1" />
            <span className="font-medium text-gray-700">{property.square_feet.toLocaleString()} ft²</span>
          </div>
          <div className="flex flex-col items-center p-3 bg-[#BDDDE4]/10 dark:bg-gray-900 rounded-lg">
            <Bed className="size-5 text-[#4A7D8A] dark:text-indigo-400 mb-1" />
            <span className="font-medium text-gray-700">{property.bedrooms} Beds</span>
          </div>
          <div className="flex flex-col items-center p-3 bg-[#BDDDE4]/10 dark:bg-gray-900 rounded-lg">
            <Bath className="size-5 text-[#4A7D8A] dark:text-teal-400 mb-1" />
            <span className="font-medium text-gray-700">{property.bathrooms} Baths</span>
          </div>
        </div>
        
        {hasPendingOffers && (
          <div className="mt-4 bg-[#BDDDE4]/20 dark:bg-indigo-900/30 p-3 rounded-md text-xs text-center font-medium text-[#4A7D8A] dark:text-indigo-300">
            {offers.filter(o => o.status === 'Pending').length} pending {offers.filter(o => o.status === 'Pending').length === 1 ? 'offer' : 'offers'}
          </div>
        )}
      </CardContent>
      
      <CardFooter className="pt-0 pb-5 px-5 mt-auto">
        <Button className="ml-auto flex items-center gap-2 bg-gradient-to-r from-[#9CC8D3] to-[#7AACBA] hover:opacity-90 text-gray-800 rounded-full px-5 py-2 text-sm font-medium transition-all duration-200 shadow-md">
          View Details
          <ArrowRight className="size-4" />
        </Button>
      </CardFooter>
    </Card>
  );
};