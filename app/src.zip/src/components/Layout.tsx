import { Link, Outlet, useLocation } from 'react-router-dom';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Button } from '@/components/ui/button';
import { useWallet } from '@/hooks/useWallet';
import { useAuth } from '@/hooks/useAuth';
import { useState, useEffect } from 'react';
import { Moon, Sun, Home, User, Clock, DollarSign, Menu, X } from 'lucide-react';

const Layout = () => {
  const location = useLocation();
  const { disconnect } = useWallet();
  const { authenticate, logout, token } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(
    localStorage.getItem('theme') === 'dark' || 
    (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)
  );

  const navItems = [
    { path: '/', label: 'Properties', icon: <Home className="h-4 w-4 mr-2" /> },
    { path: '/my-properties', label: 'My Properties', icon: <User className="h-4 w-4 mr-2" /> },
    { path: '/my-offers', label: 'My Offers', icon: <DollarSign className="h-4 w-4 mr-2" /> },
    { path: '/transactions', label: 'Transaction History', icon: <Clock className="h-4 w-4 mr-2" /> },
  ];

  // Handle theme toggle
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header with new color scheme */}
      <header className="sticky top-0 z-50 w-full border-b bg-[#BDDDE4]/95 backdrop-blur supports-[backdrop-filter]:bg-[#BDDDE4]/80 shadow-sm">
        <div className="container mx-auto px-5 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center text-xl font-bold text-gray-800">
                <div className="w-9 h-9 mr-3 bg-gradient-to-r from-[#9CC8D3] to-[#7AACBA] rounded-lg flex items-center justify-center shadow-md">
                  <span className="text-white font-bold text-sm">RE</span>
                </div>
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#4A7D8A] to-[#7AACBA]">Real Estate NFT</span>
              </Link>
              
              {/* Desktop Navigation */}
              <div className="hidden md:flex ml-12 items-center space-x-2">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      location.pathname === item.path 
                        ? 'bg-[#BDDDE4]/30 text-[#4A7D8A] font-medium' 
                        : 'text-gray-700 hover:text-[#4A7D8A] hover:bg-[#BDDDE4]/10'
                    }`}
                  >
                    {item.icon}
                    {item.label}
                  </Link>
                ))}
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Theme toggle button */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="rounded-full text-gray-700 hover:bg-[#BDDDE4]/20"
                title={isDarkMode ? "Switch to light mode" : "Switch to dark mode"}
              >
                {isDarkMode ? (
                  <Sun className="h-5 w-5 text-yellow-500" />
                ) : (
                  <Moon className="h-5 w-5 text-[#4A7D8A]" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
              
              {/* Desktop buttons */}
              <div className="hidden md:flex items-center space-x-4">
                <WalletMultiButton className="!bg-gradient-to-r from-[#9CC8D3] to-[#7AACBA] hover:!opacity-90 !rounded-md !h-10 !px-5 !py-2 shadow-md !text-gray-800" />
                
                {token ? (
                  <Button
                    variant="outline"
                    onClick={() => {
                      logout();
                      disconnect();
                    }}
                    size="sm"
                    className="border-[#BDDDE4] hover:border-[#9CC8D3] hover:bg-[#BDDDE4]/10 text-gray-700 px-4"
                  >
                    Sign Out
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    onClick={authenticate}
                    size="sm"
                    className="border-[#BDDDE4] hover:border-[#9CC8D3] hover:bg-[#BDDDE4]/10 text-gray-700 px-4"
                  >
                    Authenticate
                  </Button>
                )}
              </div>
              
              {/* Mobile menu button */}
              <div className="md:hidden">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="relative hover:bg-[#BDDDE4]/20 text-gray-700 focus:outline-none"
                >
                  <span className="sr-only">{isMenuOpen ? "Close menu" : "Open menu"}</span>
                  {isMenuOpen ? (
                    <X className="h-6 w-6" />
                  ) : (
                    <Menu className="h-6 w-6" />
                  )}
                </Button>
              </div>
            </div>
          </div>
          
          {/* Mobile menu */}
          <div className={`md:hidden overflow-hidden transition-all duration-300 ease-in-out ${isMenuOpen ? "max-h-[400px] opacity-100" : "max-h-0 opacity-0"}`}>
            <div className="px-3 pt-3 pb-4 space-y-2">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center px-4 py-3 rounded-md text-base font-medium ${
                    location.pathname === item.path 
                      ? 'bg-[#BDDDE4]/30 text-[#4A7D8A]' 
                      : 'text-gray-700 hover:bg-[#BDDDE4]/10 hover:text-[#4A7D8A]'
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.icon}
                  {item.label}
                </Link>
              ))}
              <div className="pt-5 pb-3 space-y-3 border-t border-[#BDDDE4]/30 mt-4">
                <WalletMultiButton className="!bg-gradient-to-r from-[#9CC8D3] to-[#7AACBA] hover:!opacity-90 !rounded-md !h-10 !w-full !text-gray-800" />
                {token ? (
                  <Button
                    variant="outline"
                    onClick={() => {
                      logout();
                      disconnect();
                      setIsMenuOpen(false);
                    }}
                    className="w-full border-[#BDDDE4] text-gray-700"
                  >
                    Sign Out
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    onClick={() => {
                      authenticate();
                      setIsMenuOpen(false);
                    }}
                    className="w-full border-[#BDDDE4] text-gray-700"
                  >
                    Authenticate
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main content with subtle background pattern */}
      <main className="flex-grow relative">
        <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none" />
        <div className="max-w-7xl mx-auto py-10 px-5 sm:px-6 lg:px-8 relative">
          <Outlet />
        </div>
      </main>
      
      {/* Footer */}
      <footer className="bg-[#BDDDE4]/20 border-t border-[#BDDDE4]/30 py-8">
        <div className="max-w-7xl mx-auto px-5 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center text-sm text-gray-600">
            <p>© {new Date().getFullYear()} Real Estate NFT Marketplace. All rights reserved.</p>
            <div className="flex space-x-8 mt-5 md:mt-0">
              <a href="#" className="hover:text-[#4A7D8A]">Privacy Policy</a>
              <a href="#" className="hover:text-[#4A7D8A]">Terms of Service</a>
              <a href="#" className="hover:text-[#4A7D8A]">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;